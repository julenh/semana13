const serverURL = window.location.hostname + ":" + window.location.port;

setupSockets = window.addEventListener('deviceorientation', function (e) {
    const socket = io.connect(serverURL, {secure: true});
    //socket.on('phone-move',{ alpha: e.alpha, beta: e.beta, gamma: e.gamma});
    if(socket.on('phone-move', alpha)){
        window.dispatchEvent(new keyboardEvent("keydown", {key: "ArrowLeft"}));
    }
    if(socket.on('phone-move', e.alpha)){
        window.dispatchEvent(new keyboardEvent("keydown", {key: "ArrowRight"}));
    }
    if(socket.on('phone-move', beta)){
        window.dispatchEvent(new keyboardEvent("keydown", {key: "ArrowUp"}));
    }
    if(socket.on('phone-move', e.beta)){
        window.dispatchEvent(new keyboardEvent("keydown", {key: "ArrowDown"}));
    }

})